#define REPORT_EVERY 10  // seconds

void setupTimer();

void timer();