#ifndef __LUFA_H__
#define __LUFA_H__

/*
 * This file is here only because Arduino wants it...
 */

#include <Arduino.h>
#define F_USB F_CPU

#include <LUFA/LUFA/Drivers/USB/USB.h>

#endif